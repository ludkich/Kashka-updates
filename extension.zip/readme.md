Выгрузка базы в консоли
    загрузть func.js
    загрузть idb.js
    загрузть db.js
    Db.exportUserGroupsToFile()
    Db.exportGroupsToFile()

    Импорт:
        Db.importUserGroups()

