// === Глобальные переменные и функции, доступные из других файлов ===

var LogLabel = "КАШКА ВКШКА";
var ArkhCities = [];

var AccessTokens;
let CurrentTokenIndex = 0;
let TokensLoaded  = false;

function parseVKLastSeen(last_seen) {
  if (last_seen) {
    const lastSeenDate = new Date(last_seen.time * 1000).toLocaleString().slice(0, -3);
    const platforms = {
      1: 'моб. версия сайта',
      2: 'iPhone',
      3: 'iPad',
      4: 'Android',
      5: 'Windows Phone',
      6: 'Windows 10',
      7: 'полн. версия сайта'
    };
    const lastSeenPlatform = platforms[last_seen.platform] || 'неизвестно';
    return [lastSeenDate, lastSeenPlatform];
  }
  return ['неизвестно', 'неизвестно'];
}

function getVKFileName(path) {
  return path.split('/').pop().split('?')[0];
}

function moreBtnVisible() {
  const el = $(".ui_load_more_btn");
  return el.length && el.is(":visible");
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

function getResourceLink() {
  return $("meta[property='og:url']").attr("content");
}

async function isArkhUser(user) {
  return (await getArkhCities()).some(c => c.id === user.city?.id);
}

function checkTokens() {
  return Array.isArray(AccessTokens) && AccessTokens.length > 0;
}

async function getAccessToken() {
  if (!TokensLoaded) {
    const result = await new Promise(resolve => {
      chrome.storage.local.get(['AccessTokens', 'TokenIndex'], resolve);
    });

    AccessTokens = result.AccessTokens;
    if (!AccessTokens || AccessTokens.length === 0) {
      return null
    }
    CurrentTokenIndex = result.TokenIndex || 0;
    TokensLoaded = true;
  }

  const token = AccessTokens[CurrentTokenIndex % AccessTokens.length];
  CurrentTokenIndex = (CurrentTokenIndex + 1) % AccessTokens.length;

  // Обновим индекс в хранилище (можно не делать каждый раз, но это безопасно)
  chrome.storage.local.set({ TokenIndex: CurrentTokenIndex });

  return token;
}

async function getArkhCities() {
  if (ArkhCities.length > 0) {
    return ArkhCities;
  }

  try {
    const url = chrome.runtime.getURL('/assets/vk_city.json');
    const response = await fetch(url);
    const data = await response.json();
    ArkhCities = data.response.items || [];
    return ArkhCities
  } catch (e) {
    console.error('Ошибка загрузки городов:', e);
  }
}

// === Загрузка записей с прокруткой (например, лайки, комментарии и т.п.) ===

async function loadRows(processLoadingFlagFunc, counterSelector) {
  while (processLoadingFlagFunc()) {
    const page = $('#box_layer_wrap:visible, #wk_layer_wrap:visible').first();

    if (page.length) {
      page.scrollTop(page.scrollTop() + $(window).height());
    } else {
      window.scrollBy(0, window.innerHeight * 10);
    }

    await sleep(250);

    log('wait', 'Загружаю... ' + $(counterSelector).length + " записей")
  }

  log('success', 'Записи загружены: ' + $(counterSelector).length + " записей")

}

function log(status, text) {
  let statusMessage;
  switch (status) {
    case 'success':
      statusMessage = "✅";
      break;
    case 'error':
      statusMessage = "❌";
      break;
    case 'warn':
      statusMessage = "⚠️";
      break;
    case 'wait':
      statusMessage = "⏳";
      break;
    case 'info':
      statusMessage = "ℹ️";
      break;
    default:
      statusMessage = "❓";
  }

  console.log(`${LogLabel} - ${statusMessage} ${text}`);
}
