(async function () {
    let resourceLink = getResourceLink();
    if (!resourceLink) {
        return
    }
    const resourceShortName = resourceLink.split('/').pop();

    if (/^https:\/\/vk\.com\/(club|public)/.test(resourceLink)) {
        const match = resourceLink.match(/\d+/);

        if (match && Db.getGroupById(match[0])) {
            resourceLink = resourceLink + ' *'
        }
    }
    const $infoContainer = $(`
            <div id="inf">
                Дополнительные сведения <a id="inf_close">(скрыть)</a>
                <div><span>${resourceLink}</span></div>
            </div>
        `);

    $('body').append($infoContainer);
    if (/^id\d+$/.test(resourceShortName)) {
        const userInfo = (await VkApi.getUsers([resourceShortName]))[0];

        if (userInfo) {
            const vkId = userInfo.id;

            if (userInfo.deactivated) {
                const status = userInfo.deactivated === 'deleted' ? 'Страница удалена' : 'Страница заблокирована';
                $infoContainer.append(`<div>${status}</div>`);
            }

            const [lastSeenDate, lastSeenPlatform] = parseVKLastSeen(userInfo.last_seen);

            const detailsHTML = `
                    <div><span>Активность: ${lastSeenDate}</span></div>
                    <div><span>Доступ с: ${lastSeenPlatform}</span></div>
                    <div><a id="comment_link" href="https://vk.com/feed?obj=${vkId}&q=&section=mentions" target="_blank">Комментарии</a></div>
                `;
            $infoContainer.append(detailsHTML);
        }

        const groups = await Db.getUserGroups(userInfo.id); 

        if (!groups || groups.length === 0) {
            $infoContainer.append(`
            <div class="card-panel yellow lighten-4">
                <span class="black-text">Группы не найдены</span>
            </div>
            `);
            return;
        }


        // Группы
  $infoContainer.append(`<div style="font-weight: 500;">Группы (${groups.length}):</div>`);

        // Список групп — <ul class="collection">
  const $list = $('<div class="group-link-list"></div>');

        groups.forEach(group => {
            const name = group.name || `Группа ${group.id}`;
            const url = `https://vk.com/club${group.id}`;

    const $link = $(`
      <div>
        <a href="${url}" target="_blank" style="text-decoration: none; color: #1565c0;">
          ${name}
        </a>
      </div>
    `);

    $list.append($link);
        });

  $infoContainer.append($list);

    }

    // Обработчик для скрытия информации
    $("#inf_close").on("click", () => $infoContainer.hide());
})();
