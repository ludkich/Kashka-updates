window.addEventListener("load", async () => {

    chrome.storage.local.get("kashka", async (data) => {
        const lastVersion = data.kashka;
        const currentVersion = chrome.runtime.getManifest().version;
        if (!lastVersion) {
            log('error', 'Ошибка при загрузке версии...');
        } else if (lastVersion === currentVersion) {
            log('success', 'Загружена актуальная версия');
        } else {
            log('info', `Доступно обновление: ${lastVersion} (установлена ${currentVersion})`);
            log('info', 'Ссылка на ZIP: https://github.com/ludkich/Kashka-updates/raw/main/extension.zip');
        }
    });
});