async function regionalLikes() {
    likerSelector = ".fans_fan_row[data-id]"
    await loadRows(moreBtnVisible, likerSelector)

    const usersIds = $(likerSelector).map(function () {
        return $(this).data("id");
    }).get();

    const users = await VkApi.getUsers(usersIds);

    $(likerSelector).each(async function () {
        const id = $(this).data("id");

        const user = users.find(u => u.id === id);
        if (await isArkhUser(user)) {
            $(this).find('.fans_fan_name').append(user.city.title);
        } else {
            $(this).hide();
        }
    });
    log('success', 'Готово!!!')

}