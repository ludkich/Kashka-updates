const DBPromise = idb.openDB('vk-users-db', 2, {
    upgrade(db) {
        if (!db.objectStoreNames.contains('groups')) {
            db.createObjectStore('groups', { keyPath: 'id' });
        }
        if (!db.objectStoreNames.contains('user_groups')) {
            const store = db.createObjectStore('user_groups', { keyPath: ['user_id', 'group_id'] });
            store.createIndex('user_id', 'user_id');
            store.createIndex('group_id', 'group_id');
        }
    }
});


const Db = {
    addUsersToGroup: async function (users, groupId) {
        const db = await DBPromise;
        const tx = db.transaction('user_groups', 'readwrite');
        const store = tx.objectStore('user_groups');
        const parseDate = new Date().toISOString();

        for (const userId of users) {
            const key = [parseInt(userId), parseInt(groupId)];
            const existing = await store.get(key);
            if (!existing) {
                await store.put({
                    user_id: parseInt(userId),
                    group_id: parseInt(groupId),
                    parse_date: parseDate
                });
            }
        }
        await tx.done;
    },

    addOrUpdateGroup: async function (id, name, membersCount, parsedCount) {
        const db = await DBPromise;
        const tx = db.transaction('groups', 'readwrite');
        const store = tx.objectStore('groups');

        id = parseInt(id);
        const existingGroup = await store.get(id);

        if (!existingGroup) {
            const newGroup = {
                id: id,
                name: name,
                parsedCount: parsedCount,
                membersCount: membersCount
            };
            await store.put(newGroup);
        } else {
            existingGroup.name = name;
            existingGroup.parsedCount = parsedCount;
            existingGroup.membersCount = membersCount;

            await store.put(existingGroup);
        }

        await tx.done;
    },

    getUserGroups: async function (userId) {
        const db = await DBPromise;

        // Получаем user_groups по userId
        const tx1 = db.transaction('user_groups', 'readonly');
        const userGroupsStore = tx1.objectStore('user_groups');
        const userGroupsIndex = userGroupsStore.index('user_id');
        const userGroups = await userGroupsIndex.getAll(parseInt(userId));
        await tx1.done;

        // Если групп нет, возвращаем пустой массив
        if (userGroups.length === 0) return [];

        // Получаем store groups для чтения
        const tx2 = db.transaction('groups', 'readonly');
        const groupsStore = tx2.objectStore('groups');

        // Для каждой user_group ищем детали группы
        const detailedGroups = await Promise.all(
            userGroups.map(async (ug) => {
                const groupData = await groupsStore.get(ug.group_id);
                return {
                    id: groupData.id,
                    name: groupData.name,
                    parseDate: ug.parse_date
                };
            })
        );

        await tx2.done;

        return detailedGroups;
    },

    getGroups: async function () {
        const db = await DBPromise;
        const tx = db.transaction('groups', 'readonly');
        const groups = await tx.objectStore('groups').getAll();
        await tx.done;
        return groups;
    },

    getGroupById: async function (groupId) {
        const db = await DBPromise;

        const tx = db.transaction('groups', 'readonly');
        const groupsStore = tx.objectStore('groups');

        const groupData = await groupsStore.get(groupId);
        await tx.done;

        return groupData || null;
    },

    
    syncGroupsToStorage: async function () {
        const groups = await this.getGroups();  // возвращает [{id, name, membersCount}, ...]

        chrome.storage.local.set({ groups: groups }, () => {
            log('success', `Готово!!!`)
        });
    },

    exportUserGroupsToFile: async function (batchSize = 100000) {
        const db = await DBPromise;
        const tx = db.transaction('user_groups', 'readonly');
        const store = tx.objectStore('user_groups');

        const encoder = new TextEncoder();

        let cursor = await store.openCursor();
        let total = 0;

        const stream = new ReadableStream({
            async pull(controller) {
                const batch = [];

                // читаем до batchSize записей
                while (cursor && batch.length < batchSize) {
                    batch.push(cursor.value);
                    cursor = await cursor.continue();
                }

                if (batch.length > 0) {
                    const chunk = batch.map(item => JSON.stringify(item)).join('\n') + '\n';
                    controller.enqueue(encoder.encode(chunk));
                    total += batch.length;
                    log('wait', `Exported ${total} records...`);
                }

                // если курсор завершился, закрываем поток
                if (!cursor) {
                    controller.close();
                    log('success', `Export complete. Total records: ${total}`);
                }
            }
        });

        const blob = await new Response(stream).blob();
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'user_groups.jsonl';
        a.click();
        a.remove();
        URL.revokeObjectURL(url);
    },

    exportGroupsToFile: async function () {
        const db = await DBPromise;
        const tx = db.transaction('groups', 'readonly');
        const store = tx.objectStore('groups');
        const allGroups = await store.getAll();
        await tx.done;

        const blob = new Blob(
            [JSON.stringify(allGroups, null, 2)],
            { type: 'application/json' }
        );

        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'groups.json';
        a.click();
        a.remove();
        URL.revokeObjectURL(url);

        log('success', `Exported ${allGroups.length} groups`);
    },

    importUserGroupsFromFile: async function (file, batchSize = 10000) {
        log('info', `Импорт user_groups`);
        const text = await file.text();
        const lines = text.split('\n').filter(line => line.trim());

        const db = await DBPromise;

        let batch = [];
        let totalImported = 0;

        for (const line of lines) {
            try {
                const record = JSON.parse(line);
                batch.push(record);

                if (batch.length >= batchSize) {
                    await writeBatch(batch);
                    totalImported += batch.length;
                    log('wait', `Импортировано ${totalImported} записей`);

                    batch = [];
                }
            } catch (e) {
                log('error', `Ошибка парсинга строки:` + line + e);
            }
        }

        if (batch.length > 0) {
            await writeBatch(batch);
            totalImported += batch.length;
        }

        log('success', `Готово, всего импортировано ${totalImported} записей`);

        async function writeBatch(batch) {
            const tx = db.transaction('user_groups', 'readwrite');
            const store = tx.objectStore('user_groups');

            for (const item of batch) {
                await store.put({
                    user_id: parseInt(item.user_id),
                    group_id: parseInt(item.group_id),
                    parse_date: item.parse_date
                });
            }

            await tx.done;
        }
    }

    ,
    importGroupsFromFile: async function (file) {
        const text = await file.text();
        let groups;
        try {
            groups = JSON.parse(text);
        } catch (e) {
            log('error', 'Ошибка парсинга groups.json:' + e);
            return;
        }

        const db = await DBPromise;
        const tx = db.transaction('groups', 'readwrite');
        const store = tx.objectStore('groups');

        for (const group of groups) {
            // Можно использовать addOrUpdateGroup, но здесь прямой put — быстрее
            await store.put({
                id: parseInt(group.id),
                name: group.name,
                membersCount: group.membersCount,
                parsedCount: group.parsedCount
            });
        }

        await tx.done;
       log('success', `Импортировано ${groups.length} групп`);
    },

    importUserGroups: async function () {
        const fileInput = document.createElement('input');
        fileInput.type = 'file';
        fileInput.accept = '.json,.jsonl';
        fileInput.onchange = async (e) => {
            const file = e.target.files[0];
            if (!file) return;

            if (file.name === 'groups.json') {
                await Db.importGroupsFromFile(file);
            } else if (file.name === 'user_groups.jsonl') {
                await Db.importUserGroupsFromFile(file);
            } else {
                log('warn', 'Неизвестный формат файла');
            }
        };
        document.body.appendChild(fileInput);
        fileInput.click();
    }
}

