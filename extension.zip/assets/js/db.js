const DBPromise = idb.openDB('vk-users-db', 2, {
    upgrade(db) {
        if (!db.objectStoreNames.contains('groups')) {
            db.createObjectStore('groups', { keyPath: 'id' });
        }
        if (!db.objectStoreNames.contains('user_groups')) {
            const store = db.createObjectStore('user_groups', { keyPath: ['user_id', 'group_id'] });
            store.createIndex('user_id', 'user_id');
            store.createIndex('group_id', 'group_id');
        }
    }
});


const Db = {

    addUserToGroup: async function (userId, groupId, parseDate = new Date().toISOString()) {
        const db = await DBPromise;
        const tx = db.transaction('user_groups', 'readwrite');
        const store = tx.objectStore('user_groups');

        userId = parseInt(userId);
        groupId = parseInt(groupId);

        const key = [userId, groupId];
        const existing = await store.get(key);

        if (!existing) {
            const record = {
                user_id: userId,
                group_id: groupId,
                parse_date: parseDate
            };
            await store.put(record);
        }

        await tx.done;
    },

    addOrUpdateGroup: async function (id, name, membersCount, parsedCount) {
        const db = await DBPromise;
        const tx = db.transaction('groups', 'readwrite');
        const store = tx.objectStore('groups');

        id = parseInt(id);
        const existingGroup = await store.get(id);

        if (!existingGroup) {
            const newGroup = {
                id: id,
                name: name,
                parsedCount: parsedCount,
                membersCount: membersCount
            };
            await store.put(newGroup);
        } else {
            existingGroup.name = name;
            existingGroup.parsedCount = parsedCount;
            existingGroup.meFmbersCount = membersCount;

            await store.put(existingGroup);
        }

        await tx.done;
    },

    getUserGroups: async function (userId) {
        const db = await DBPromise;

        // Получаем user_groups по userId
        const tx1 = db.transaction('user_groups', 'readonly');
        const userGroupsStore = tx1.objectStore('user_groups');
        const userGroupsIndex = userGroupsStore.index('user_id');
        const userGroups = await userGroupsIndex.getAll(parseInt(userId));
        await tx1.done;

        // Если групп нет, возвращаем пустой массив
        if (userGroups.length === 0) return [];

        // Получаем store groups для чтения
        const tx2 = db.transaction('groups', 'readonly');
        const groupsStore = tx2.objectStore('groups');

        // Для каждой user_group ищем детали группы
        const detailedGroups = await Promise.all(
            userGroups.map(async (ug) => {
                const groupData = await groupsStore.get(ug.group_id);
                return {
                    id: groupData.id,
                    name: groupData.name,
                    parseDate: ug.parse_date
                };
            })
        );

        await tx2.done;

        return detailedGroups;
    },

    getGroups: async function () {
        const db = await DBPromise;
        const tx = db.transaction('groups', 'readonly');
        const groups = await tx.objectStore('groups').getAll();
        await tx.done;
        return groups;
    },
    syncGroupsToStorage: async function () {
        const groups = await this.getGroups();  // возвращает [{id, name, membersCount}, ...]

        chrome.storage.local.set({ groups: groups }, () => {
            log('success', `Готово!!!`)
        });
    }
}

