$(async function () {
    $('.tabs').tabs();

    // Загрузка токенов в textarea при инициализации
    async function loadTokens() {
        return new Promise(resolve => {
            chrome.storage.local.get(['AccessTokens'], function (result) {
                const tokens = result.AccessTokens || [];
                $('#access_tokens').val(tokens.join('\n'));
                M.textareaAutoResize($('#access_tokens')); 
                M.updateTextFields();
                resolve();
            });
        });
    }

    $('#save_tokens_btn').click(function () {
        // Получаем строки, разделяем по строкам, фильтруем пустые и лишние пробелы
        const tokensRaw = $('#access_tokens').val();
        const tokens = tokensRaw
            .split('\n')
            .map(t => t.trim())
            .filter(t => t.length > 0);

        if (tokens.length === 0) {
            log('error', 'Введите хотя бы один токен')
            return;
        }

        chrome.storage.local.set({ AccessTokens: tokens, TokenIndex: 0 }, function () {
            log('success', 'Токены сохранены')
        });
    });

    // Запускаем загрузку при старте
    loadTokens();


    function renderGroupsTable(groups) {
        const $list = $('#group_stats');
        $list.empty();

        if (!groups || groups.length === 0) {
            $list.append('<tr><td colspan="3">Группы не найдены</td></tr>');
            return;
        }

        groups.forEach(({ id, name, membersCount, parsedCount }) => {
            const link = `https://vk.com/club${id}`;
            const row = `
                <tr>
                <td><a href="${link}" target="_blank">${name || `club${id}`}</a></td>
                <td>${membersCount || 0} всего</td> 
                <td>${parsedCount || 0} загружено</td> 
                </tr>`;
            $list.append(row);
        });

    }

    chrome.storage.local.get('groups', (res) => {
        renderGroupsTable(res.groups || []);
    });
});
