chrome.runtime.onMessage.addListener(
  async function (message, sender, sendResponse) {

    switch (message.type) {
      case "loadMore":
        await loadRows(moreBtnVisible, "[data-id]")
        sendResponse(1);
        break;
      case "regionalLikes":
        await regionalLikes()
        sendResponse(1);
        return true;
      //Наши комментарии
      case "regionalComments":
        await regionalComments(message.postCount)
        sendResponse(1);
        return true;
      // Запрос групп/пользователей
      case "saveReq":
        await regionalComments(message.postCount)
        sendResponse(1);
        return true;
      case "parseGroupsMembers":
        await parseGroupsMembers()
        sendResponse(1);
        return true;
      case "checkVersion":
        const currentVersion = chrome.runtime.getManifest().version;
        if (!message.version) {
          log('error', 'Ошибка при загрузке версии...');
        } else if (message.version === currentVersion) {
          log('success', 'Загружена актуальная версия');
        } else {
          log('info', `Доступно обновление: ${message.version} (установлена ${currentVersion})`);
          log('info', 'Ссылка на ZIP: https://github.com/ludkich/Kashka-updates/raw/main/extension.zip');
        }
        sendResponse(1);
        return true;
      case "check":
        sendResponse(1);
        return true;
      default:
        console.error("Unrecognised message: ", message);
    }
  }
);
