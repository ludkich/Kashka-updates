chrome.runtime.onMessage.addListener(
  async function (message, sender, sendResponse) {

    switch (message.type) {
      case "loadMore":
        await loadRows(moreBtnVisible, "[data-id]")
        sendResponse(1);
        break;
      case "regionalLikes":
        await regionalLikes()
        sendResponse(1);
        return true;
      //Наши комментарии
      case "regionalComments":
        await regionalComments(message.postCount)
        sendResponse(1);
        return true;
      // Запрос групп/пользователей
      case "saveReq":
        await regionalComments(message.postCount)
        sendResponse(1);
        return true;
      case "parseGroupsMembers":
        await parseGroupsMembers()
        sendResponse(1);
        return true;
      case "check":
        sendResponse(1);
        return true;
      default:
        console.error("Unrecognised message: ", message);
    }
  }
);
