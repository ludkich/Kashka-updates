async function regionalComments(postCount) {

  // Загрузка постов на страницу
  await loadPosts(postCount)

  // Загрузка комментариев на страницу
  await loadComments()

  //Обработка пользователей - комментаторов
  let commentsCount = await markCommenters()
  log('success', 'Готово!!! Всего найдено комментариев: ' + commentsCount)


  //Обработка пользователей - лайкеров
  let likesCount = await markLikers()
  log('success', 'Готово!!! Всего найдено лайков: ' + likesCount)

}

// Загрузка постов на страницу
async function loadPosts(posts_count) {
  //есть ссылка "еще", и количество достаточно
  function processLoadingFlagFunc() {
    var el = $("#wall_more_link");
    return el.length && el.is(":visible") && ($("._post[data-post-id]").length <= posts_count)
  }

  await loadRows(processLoadingFlagFunc, "._post[data-post-id]")
}

// Загрузка комментариев на страницу
async function loadComments() {
  while ($(".replies_next_label").length > 0) {
    await sleep(250)
    $(".replies_next_label").first().click();
    log('wait', 'Загружаю... ' + $(".reply_content").length + " комментариев")
  }
  log('success', 'Комменты загружены')
}


//Обработка пользователей - комментаторов
async function markCommenters() {
  // Список id пользователей, оставивиших комменты
  const usersIds = [...new Set(
    $("#page_wall_posts .reply_content .author[data-from-id]")
      .map(function () {
        return $(this).data("from-id");
      }).get()
  )];

  //Запрос данных по пользователям
  const users = await VkApi.getUsers(usersIds)

  let countEdited = 0;
  for (const user of users) {
    if (await isArkhUser(user)) {
      $(`#page_wall_posts .reply_content [data-from-id='${user.id}']`).each(function () {
        const originalText = $(this).text();
        //Добавить название города к имени
        $(this).text(`${originalText} **(${user.city.title})`);
        countEdited++;
      });
    } else {
      const groups = await Db.getUserGroups(user.id)
      if (groups.length > 0) {
        $(`#page_wall_posts .reply_content [data-from-id='${user.id}']`).each(function () {
          const originalText = $(this).text();
          $(this).text(`${originalText} **(групп: ${groups.length})`);
          countEdited++;
        });
      }
    }
  };

  return countEdited
}


//Обработка пользователей - лайкеров
async function markLikers() {
  // Сбор постов с лайками
  const likeSelectors = $('.PostButtonReactions__title._counter_anim_container').filter(function () {
    return $(this).text().trim() !== '';
  });
  const postsData = likeSelectors
    .closest('div._post')
    .map(function () {
      const [owner_id, item_id] = $(this).data('post-id').toString().split('_');
      return {
        owner_id: parseInt(owner_id),
        item_id: parseInt(item_id),
        type: 'post'
      };
    }).get();

  // Сбор комментариев с лайками
  const likeCommentsSelectors = $('.like_btn.like._like').filter(function () {
    return $(this).text().trim() !== '';
  });
  const commentsData = likeCommentsSelectors
    .closest('div._post')
    .map(function () {
      const [owner_id, item_id] = $(this).data('post-id').toString().split('_');
      return {
        owner_id: parseInt(owner_id),
        item_id: parseInt(item_id),
        type: 'comment'
      };
    }).get();

  const likedDataWithLikers = await VkApi.getLikers([...postsData, ...commentsData]);

  //все id пользователей
  const allLikerIds = [...new Set(likedDataWithLikers.flatMap(item => item.likerIds))];
  const allLikers = await VkApi.getUsers(allLikerIds);

  let countEdited = 0;
  for (const likedItem of likedDataWithLikers) {
    const dataContainer = $('<span>')
    for (const likerId of likedItem.likerIds) {
      var liker = allLikers.find(u => u.id === likerId);
      if (liker) {
        //У пользователя указан региональный город
        if (await isArkhUser(liker)) {
          dataContainer.append(" ").append(createUserLink(liker));
          countEdited++
        } else {
          //у пользователя есть региональные группы
          const groups = await Db.getUserGroups(liker.id)
          if (groups.length > 0) {
            dataContainer.append(" ").append(createUserLinkWithGroups(liker, groups.length));
            countEdited++;
          }
        }
      }
    }

    if (dataContainer.children().length > 0) {
      const selector = likedItem.type === 'post'
        ? `._post[data-post-id='${likedItem.owner_id}_${likedItem.item_id}'] .like_wrap:first`
        : `._post[data-post-id='${likedItem.owner_id}_${likedItem.item_id}'] ._post_content`;
      const post = $(selector);
      post.append('**').append('Лайки: ').append(dataContainer);
    }

  }
  return countEdited
}


function createUserLink(user) {
  return `<a href="https://vk.com/id${user.id}" target="_blank">${user.first_name} ${user.last_name} (${user.city.title})</a>`;
}

function createUserLinkWithGroups(user, groupCount) {
  return `<a href="https://vk.com/id${user.id}" target="_blank">${user.first_name} ${user.last_name} (групп: ${groupCount})</a>`;
}
