const moreGroupsVisible = () => {return $("span.vkuiSpinner__host.vkuiRootComponent__host:visible").length > 0;}

window.addEventListener("load", () => {
  chrome.storage.local.get("request", async ({ request }) => {
    if (!request) return;

    // const searchItems = ("знакомства 12".toUpperCase()).split(" ");
    const searchItems = (request.params.toUpperCase()).split(" ");

    await loadRows(moreGroupsVisible, "[data-testid='list_groups_items'] [data-testid='group_item_desktop_list']");

    //a= $("[data-testid='list_groups_items'] [data-testid='group_item_desktop_list'] a div.vkuiTypography__host").first()
    $("[data-testid='list_groups_items'] [data-testid='group_item_desktop_list'] a div.vkuiTypography__host").each(function () {

      //const text = a.text().toUpperCase();
      const text = $(this).text().toUpperCase();

      if (!searchItems.every(item => text.includes(item))) {
        $(this).closest("[data-testid='group_item_desktop_list']").first().remove();
      }
      // TODO убрать имеющиеся items
    });
    chrome.storage.local.remove("request");
    log('success', 'Всего найдено: ' + $("[data-testid='list_groups_items'] [data-testid='group_item_desktop_list']").length + " записей")
  });
});

function saveGroups() {
  params = $("input.vkuiSearch__nativeInput").last().val()
  const items = [];
  $("[data-testid='list_groups_items'] [data-testid='group_item_desktop_list'] a.vkuiLink__host").each(function () {
    cleanHref = ($(this).attr('href').split('?'))[0];
    items.push(cleanHref);
  });
  
  saveRequestToFile(params, items)

  log('success', 'Записи загружены: ' + $(counterSelector).length + " записей")
}