async function parseGroupsMembers() {
    const resourceLink = getResourceLink();
    const groupShortName = resourceLink.split('/').pop();
    let group;
    log('info', `📄 Группа: ${groupShortName}`)
    try {
        group = (await VkApi.getGroup(groupShortName));
        log('wait', `Загружаем данные для группы: ${group.name}`)
    } catch (err) {
        log('error', "Не удалось загрузить данные группы: " + groupShortName + ": " + err.message)
        return null
    }

    const groupUsers = await VkApi.getGroupUsers(group.id, group.membersCount);

    if (groupUsers.length == 0) {
        return null
    }
    log('wait', `Сохраняем пользователей`)
    await Db.addOrUpdateGroup(group.id, group.name, group.membersCount, groupUsers.length);
    await Db.addUsersToGroup(groupUsers, group.id);
    
    //синхронизация со storage (для отображения в настройках)
    await Db.syncGroupsToStorage()

    log('wait', `Группа ${group.name} загружена`)
    return true;

}