var VK_API_VERSION = '5.199'

const VkApi = {


    vkApiErrorFunc: function (jqXHR, exception) {
        var msg = '';
        if (jqXHR.status === 0) {
            msg = 'Not connect.\n Verify Network.';
        } else if (jqXHR.status == 404) {
            msg = 'Requested page not found. [404]';
        } else if (jqXHR.status == 500) {
            msg = 'Internal Server Error [500].';
        } else if (exception === 'parsererror') {
            msg = 'Requested JSON parse failed.';
        } else if (exception === 'timeout') {
            msg = 'Time out error.';
        } else if (exception === 'abort') {
            msg = 'Ajax request aborted.';
        } else {
            msg = 'Uncaught Error.\n' + jqXHR.responseText;
        }
        alert(msg);
    },

    getGroup: async function (groupShortName) {
        await sleep(500);
        const accessToken = await getAccessToken();

        try {
            const response = await fetch(`https://api.vk.com/method/groups.getById?v=${VK_API_VERSION}&group_id=${groupShortName}&access_token=${accessToken}&fields=members_count`);
            const json = await response.json();
            if (json.error) {
                throw new Error(json.error.error_msg);
            }
            const group = json.response.groups[0];
            return {
                id: group.id,
                name: group.name,
                membersCount: group.members_count
            };

        } catch (err) {
            return undefined
        }
    },


    getGroupUsers: async function (groupId, membersCount = 0) {
        try {
            let users = [];
            let offset = 0;
            const chunkSize = 25000;

            async function vkExecute(code) {
                const accessToken = await getAccessToken();
                await sleep(5000 + Math.random() * 5000); // пауза между execute-запросами

                const url = `https://api.vk.com/method/execute?v=${VK_API_VERSION}&access_token=${accessToken}`;
                const response = await fetch(url, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: new URLSearchParams({ code })
                });
                const json = await response.json();
                if (json.error) throw new Error(json.error.error_msg);
                return json;
            }

            const maxFloodErrors = AccessTokens.length;
            let floodErrorCount = 0;
            let json;

            while (offset < membersCount) {
                const remaining = membersCount - offset;
                const loops = Math.min(25, Math.ceil(remaining / 1000)); // сколько запросов по 1000 нужно сделать, но не больше 25

                const code = `
                        var members = [];
                        var offset = ${offset};
                        var i = 0;
                        while (i < ${loops}) {
                            var part = API.groups.getMembers({"group_id": ${groupId}, "offset": offset, "count": 1000});
                            members = members + part.items;
                            offset = offset + 1000;
                            i = i + 1;
                        }
                        return {"items": members}; `;

                let success = false;
                while (!success) {
                    try {
                        json = await vkExecute(code);

                        if (json.execute_errors) {
                            if (json.execute_errors[0].error_code === 9) { // flood control
                                floodErrorCount++;
                                log('warn', `Flood control. Всего flood-ошибок: ${floodErrorCount}/${maxFloodErrors}`);
                                if (floodErrorCount >= maxFloodErrors) {
                                    throw new Error("Превышен лимит flood control ошибок");
                                }
                                continue;
                            } else {
                                throw new Error(json);
                            }
                        }
                        floodErrorCount = 0;
                        success = true;
                    } catch (err) {
                        log('error', `Ошибка запроса: ${err.message}`);
                        throw err; // выбрасываем, если это не flood или лимит достигнут
                    }
                }
                users = users.concat(json.response.items);
                offset += chunkSize;

                log('wait', `Загружено ${users.length} из ${membersCount}`)

            }
            return users.map(Number)

        } catch (err) {
            log('error', "Ошибка запроса группы: " + err.message)
            return []
        }
    },

    getUsers: async function (names) {
        const accessToken = await getAccessToken();
        const chunks = [];
        const chunkSize = 100;
        const results = [];
        // Разбиваем пользователей на чанки по 100
        for (let i = 0; i < names.length; i += chunkSize) {
            chunks.push(names.slice(i, i + chunkSize));
        }

        for (const chunk of chunks) {
            await sleep(400);

            const idsStr = chunk.join(',');
            const url = `https://api.vk.com/method/users.get?user_ids=${idsStr}&fields=city,last_seen,deactivated&access_token=${accessToken}&v=${VK_API_VERSION}`;

            try {
                const res = await fetch(url);
                const json = await res.json();

                if (json.error) {
                    log('error', "Ошибка VK API:" + json.error)
                    continue;
                }

                results.push(...json.response);
                log('wait', `Загружено ${results.length}/${names.length} пользователей`)

            } catch (err) {
                log('error', "Ошибка запроса:" + err)
            }
        }
        return results; // массив объектов с полями id, city и др.
    },

    // Поиск группы
    groupsSearch: async function (q) {
        try {
            const accessToken = await getAccessToken();
            const response = await fetch('https://api.vk.com/method/groups.search', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({
                    q: q,
                    count: '1000',
                    access_token: accessToken,
                    v: VK_API_VERSION
                })
            });

            const json = await response.json();

            if (json.error) {
                log('error', "Ошибка " + json.error.error_msg)
                return [];
            }

            const keywords = q.trim().split(/\s+/);
            return json.response.items.filter(group =>
                keywords.every(word => group.name.includes(word))
            );

        } catch (err) {
            log('error', "Ошибка groupsSearch: " + err.message)
            return [];
        }
    }
    ,

    // Поиск пользователя
    usersSearch: async function (q) {
        try {
            const accessToken = await getAccessToken();
            const response = await fetch('https://api.vk.com/method/users.search', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                body: new URLSearchParams({
                    q: q,
                    count: '1000',
                    fields: 'photo_100,last_seen,domain',
                    access_token: accessToken,
                    v: VK_API_VERSION
                })
            });

            const json = await response.json();

            if (json.error) {
                log('error',"Ошибка VK API: " + json.error.error_msg)
                return [];
            }

            return json.response.items || [];

        } catch (err) {
            log('error', "Ошибка usersSearch: " + err.message)
            return [];
        }
    },

    // Поиск пользователей, поставивших лайк
    getLikers: async function (posts) {
        async function getLikersBatchExecute(postsBatch) {
            const code = `
                var posts = ${JSON.stringify(postsBatch)};
                var results = [];
                var i = 0;

                while (i < posts.length) {
                var p = posts[i];
                var res = API.likes.getList({
                    type: p.type,
                    owner_id: p.owner_id,
                    item_id: p.item_id,
                    count: 1000
                });

                results.push({
                    type: p.type,
                    owner_id: p.owner_id,
                    item_id: p.item_id,
                    likerIds: res.items
                });

                i = i + 1;
                }

                return results;
            `;

            const accessToken = await getAccessToken();
            await sleep(400); // пауза между execute-запросами
            const response = await fetch('https://api.vk.com/method/execute', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({
                    code,
                    access_token: accessToken,
                    v: VK_API_VERSION
                })
            });

            const data = await response.json();

            if (data.error) {
                throw new Error(data.error.error_msg);
            }

            return data.response;
        }

        const result = [];
        const batchSize = 25;

        for (let i = 0; i < posts.length; i += batchSize) {
            const batch = posts.slice(i, i + batchSize);
            const batchResult = await getLikersBatchExecute(batch);
            result.push(...batchResult);
            log('wait', `Загружено ${result.length}/${posts.length} лайкеров`)
        }

        return result;
    }


}