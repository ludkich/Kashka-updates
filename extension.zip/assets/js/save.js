function getFileName(params) {
  const fileNames = {
    groups: `Группы - ${params}.vk`,
    users: `Пользователи - ${params}.vk`
  };

  const fileName = fileNames[requestType()];
  return fileName ? [fileName, false] : ['Ошибка имени', true];
}

function saveRequestToFile(params, items) {
  
  if (!items || (items.length == 0)) {
    log('success', "Нечего сохранять...")
  }

  var request = {
    link: new URL(window.location.href),
    params: params,
    items: items
  }
  const [fileName, err] = getFileName(params);
  saveToFile(request, fileName)
}

function saveToFile(data, fileName) {
  textToWrite = JSON.stringify(data);
  textFileAsBlob = new Blob([textToWrite], { type: 'text/plain' });
  downloadLink = document.createElement("a");
  downloadLink.download = fileName;
  downloadLink.href = window.webkitURL.createObjectURL(textFileAsBlob);
  downloadLink.click();
}