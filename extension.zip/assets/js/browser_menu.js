// Пролистать
$('#load_more_btn').on("click", async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const response = await chrome.tabs.sendMessage(tab.id, {
    type: "loadMore",
  });
  $('#load_more_btn').text("+");
});

// города на лайках/списках
$('#likes_btn').on("click", async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const response = await chrome.tabs.sendMessage(tab.id, {
    type: "regionalLikes",
  });
  $('#likes_btn').text("+");
});

// Наши комментарии
$('#comments_btn').on("click", async () => {
  const postCount = $('#post500').is(':checked') ? 500 :
    $('#post1000').is(':checked') ? 1000 : 100;

  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const response = await chrome.tabs.sendMessage(tab.id, {
    type: "regionalComments",
    postCount: postCount
  });
  $('#comments_btn').text("+");
});



// Выбор файла - загрузка
$('#open_req_btn').on("click", () => $('#file_input').trigger('click'));

$('#file_input').on('change', function (event) {
  const rFiles = event.target.files;
  let rFileIndex = 0;
  const requests = [];
  const reader = new FileReader();

  reader.onload = function (e) {
    const request = JSON.parse(e.target.result);
    requests.push(request);
    rFileIndex++;

    if (rFileIndex < rFiles.length) {
      reader.readAsText(rFiles[rFileIndex]);
    } else {
      // TODO
      if (requests.length > 0) {
        chrome.storage.local.set({ requests });
        chrome.tabs.create({ url: '/pages/' + requests[0].type + '.html' });
      }
    }
  };

  reader.readAsText(rFiles[rFileIndex]);
});

// Спарсить пользователей групп
$('#save_req_btn').on('click', async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const response = await chrome.tabs.sendMessage(tab.id, {
    type: "saveReq"
  });

  $('#save_req_btn').text("+");
});

// Спарсить пользователей групп
$('#parse_group_users_btn').on('click', async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const response = await chrome.tabs.sendMessage(tab.id, {
    type: "parseGroupsMembers"
  });

  $('#parse_group_users_btn').text("+");
});


$('#check_btn').on('click', async function () {
  chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
    chrome.tabs.sendMessage(tabs[0].id, { type: 'check' }, response => {
    });
  });

});
