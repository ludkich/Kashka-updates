async function sendMessageToActiveTab(message) {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab) throw Alert("No active tab found");
  return chrome.tabs.sendMessage(tab.id, message);
}

chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
  const url = tabs[0]?.url || "";
  if (!url.includes("vk.com")) {
    document.body.innerHTML = `
      <div class="container center-align" style="margin-top: 50px;">
        <i class="large material-icons red-text">error_outline</i>
        <h5>Расширение доступно только на <strong>vk.com</strong></h5>
        <p>Пожалуйста, откройте вкладку ВКонтакте, чтобы использовать это расширение.</p>
      </div>
    `;
    // Инициализация Materialize, если нужна
    M.AutoInit();
  } else {
    initPopup(); // если все ок, запускаем функцию инициализации событий
  }
});

async function initPopup() {
  const token = await getAccessToken()
  if (!token) {
    document.body.innerHTML = `
      <div class="container center-align" style="margin-top: 50px;">
        <i class="large material-icons red-text">error_outline</i>
        <h5>Токены VK API не найдены</h5>
        <p>Пожалуйста добавьте токены в настройках расширения</p>
      </div>
    `;
    return
  }

  // Пролистать
  $('#load_more_btn').on("click", async () => {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    await sendMessageToActiveTab({ type: "loadMore" });
    $('#load_more_btn').text("+");
  });

  // города на лайках/списках
  $('#likes_btn').on("click", async () => {
    await sendMessageToActiveTab({ type: "regionalLikes" });
    $('#likes_btn').text("+");
  });

  // Наши комментарии
  $('#comments_btn').on("click", async () => {
    const postCount = $('#post500').is(':checked') ? 500 :
      $('#post1000').is(':checked') ? 1000 : 100;

    await sendMessageToActiveTab({
      type: "regionalComments",
      postCount: postCount
    });
    $('#comments_btn').text("+");
  });



  // Выбор файла - загрузка
  $('#open_req_btn').on("click", () => $('#file_input').trigger('click'));

  $('#file_input').on('change', function (event) {
    const rFiles = event.target.files;
    let rFileIndex = 0;
    const requests = [];
    const reader = new FileReader();

    reader.onload = function (e) {
      const request = JSON.parse(e.target.result);
      requests.push(request);
      rFileIndex++;

      if (rFileIndex < rFiles.length) {
        reader.readAsText(rFiles[rFileIndex]);
      } else {
        // TODO
        if (requests.length > 0) {
          chrome.storage.local.set({ requests });
          chrome.tabs.create({ url: '/pages/' + requests[0].type + '.html' });
        }
      }
    };

    reader.readAsText(rFiles[rFileIndex]);
  });

  // Спарсить пользователей групп
  $('#save_req_btn').on('click', async () => {
    await sendMessageToActiveTab({ type: "saveReq" });
    $('#save_req_btn').text("+");
  });

  // Спарсить пользователей групп
  $('#parse_group_users_btn').on('click', async () => {
    await sendMessageToActiveTab({ type: "parseGroupsMembers" });
    $('#parse_group_users_btn').text("+");
  });

  $('#check_btn').on('click', async () => {
    await sendMessageToActiveTab({ type: "check" });
    $('#check_btn').text("+");
  });

  async function checkVersionAndSend() {
    let version = null;
    try {
      const data = await $.getJSON("https://raw.githubusercontent.com/ludkich/Kashka-updates/main/version.json");
      version = data.version;
    } catch (error) {
      version = null;
    }

    await sendMessageToActiveTab({
      type: "checkVersion",
      version: version
    });
  }

  checkVersionAndSend();
}