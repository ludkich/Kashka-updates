// // Функция для копирования и вставки элемента
// function copyAndInsertElement(user, active = {}) {
//     const $hiddenElement = $('.user_template:first');
//     const $targetElement = $('.results:first');

//     if (!$hiddenElement.length) {
//         console.error('Скрытый элемент не найден');
//         return;
//     }

//     // Клонируем элемент и находим внутренние элементы
//     const $clonedElement = $hiddenElement.clone();
//     const $img = $clonedElement.find('img');
//     const $name = $clonedElement.find('span.title.name');
//     const $domain = $clonedElement.find('span.title.domain');
//     const $ident = $clonedElement.find('span.title.ident');
//     const $last_seen = $clonedElement.find('p.title.last_seen');
//     const $link = $clonedElement.find('a.secondary-content');

//     // Устанавливаем свойства и стили
//     $img.attr("src", user.photo_100)
//         .css("border", active.photo_100 ? "3px solid red" : "");

//     $name.text(user.last_name + " " + user.first_name)
//         .css("color", active.name ? "red" : "");

//     $domain.text(user.domain)
//         .css("color", active.domain ? "red" : "");

//     $ident.text(`id${user.id}`);

//     const [lastSeenDate, lastSeenPlatform] = parseVKLastSeen(user.last_seen);
//     $last_seen.text(`${lastSeenDate} (${lastSeenPlatform})`);


//     $link.attr("href", `https://vk.com/id${user.id}`);

//     // Делаем элемент видимым и вставляем его
//     $clonedElement.css('display', 'block');
//     $targetElement.append($clonedElement);
// }


// var users = []
// var user_search = { name: '' }

// // Обработчик клика на кнопку поиска
// $('.search-btn').on("click", function (e) {
//     e.preventDefault();
//     $(".results").empty();
//     user_search.name = $("#user_name").val().trim();
//     if (user_search.name.length < 5) {
//         log('error', "Маловато будет...")
//         return;
//     }
//     users = VkApi.usersSearch(user_search.name);
//     $("p.stat").text(`Найдено: ${users.length}`);

//     if (users.length) {
//         users.forEach(copyAndInsertElement);
//     }
//     log('success', "Готово!")

// });


// // Обработчик клика на кнопку поиска
// $('.download-btn').on("click", function (e) {
//     e.preventDefault();
//     saveRequestToFile('users', { name: user_search.name }, users)
// });

// // Установка значений формы при загрузке из файла
// function setFormValues(search) {
//     const $user_name = $('#user_name');
//     $user_name.val(search.name);
// }

// // Сравнение групп, вывод отличий
// function analyzeItems(oldUsers, newUsers) {
//     newUsers.forEach(newUser => {
//         let active = { name: false, domain: false, photo_100: false };
//         let isNewUser = true;

//         for (const oldUser of oldUsers) {
//             if (oldUser.id === newUser.id) {
//                 isNewUser = false;
//                 active.name = (oldUser.last_name !== newUser.last_name) || (oldUser.first_name !== newUser.first_name);
//                 active.domain = oldUser.domain !== newUser.domain;
//                 active.photo_100 = getVKFileName(oldUser.photo_100) !== getVKFileName(newUser.photo_100);
//                 break;
//             }
//         }

//         if (isNewUser || Object.values(active).some(Boolean)) {
//             copyAndInsertElement(newUser, active);
//         }
//     });
// }


// //проверка наличия запросов при открытии файлов
// chrome.storage.local.get(['requests'], function (store) {
//     const requests = store.requests || [];
//     log('success', `${LogLabel}/ requests ${requests.length}`)

//     if (requests.length === 0) return;

//     const request = requests.shift();
//     chrome.storage.local.set({ requests });

//     setFormValues(request.search);
//     user_search = request.search;
//     users = VkApi.usersSearch(user_search.name);
//     analyzeItems(request.items, users);

//     // Открыть вкладку для следующего запроса или показать сообщение
//     requests.length > 0
//         ? chrome.tabs.create({ url: `/pages/${requests[0].type}.html` })
//         : alert("OK!");
// });
